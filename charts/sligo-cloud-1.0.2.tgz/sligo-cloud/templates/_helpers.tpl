{{/*
Expand the name of the chart.
*/}}
{{- define "sligo-cloud.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "sligo-cloud.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "sligo-cloud.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "sligo-cloud.labels" -}}
helm.sh/chart: {{ include "sligo-cloud.chart" . }}
{{ include "sligo-cloud.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "sligo-cloud.selectorLabels" -}}
app.kubernetes.io/name: {{ include "sligo-cloud.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
App component labels
*/}}
{{- define "sligo-cloud.app.labels" -}}
{{ include "sligo-cloud.labels" . }}
app.kubernetes.io/component: app
{{- end }}

{{- define "sligo-cloud.app.selectorLabels" -}}
{{ include "sligo-cloud.selectorLabels" . }}
app.kubernetes.io/component: app
{{- end }}

{{/*
Release setup component labels
*/}}
{{- define "sligo-cloud.releaseSetup.labels" -}}
{{ include "sligo-cloud.labels" . }}
app.kubernetes.io/component: release-setup
{{- end }}

{{/*
Backend component labels
*/}}
{{- define "sligo-cloud.backend.labels" -}}
{{ include "sligo-cloud.labels" . }}
app.kubernetes.io/component: backend
{{- end }}

{{- define "sligo-cloud.backend.selectorLabels" -}}
{{ include "sligo-cloud.selectorLabels" . }}
app.kubernetes.io/component: backend
{{- end }}

{{/*
MCP Gateway component labels
*/}}
{{- define "sligo-cloud.mcpGateway.labels" -}}
{{ include "sligo-cloud.labels" . }}
app.kubernetes.io/component: mcp-gateway
{{- end }}

{{- define "sligo-cloud.mcpGateway.selectorLabels" -}}
{{ include "sligo-cloud.selectorLabels" . }}
app.kubernetes.io/component: mcp-gateway
{{- end }}

{{/*
Database component labels
*/}}
{{- define "sligo-cloud.database.labels" -}}
{{ include "sligo-cloud.labels" . }}
app.kubernetes.io/component: database
{{- end }}

{{- define "sligo-cloud.database.selectorLabels" -}}
{{ include "sligo-cloud.selectorLabels" . }}
app.kubernetes.io/component: database
{{- end }}

{{/*
Redis component labels
*/}}
{{- define "sligo-cloud.redis.labels" -}}
{{ include "sligo-cloud.labels" . }}
app.kubernetes.io/component: redis
{{- end }}

{{- define "sligo-cloud.redis.selectorLabels" -}}
{{ include "sligo-cloud.selectorLabels" . }}
app.kubernetes.io/component: redis
{{- end }}

{{/*
Image pull secrets
*/}}
{{- define "sligo-cloud.imagePullSecrets" -}}
{{- if .Values.global.imagePullSecrets }}
imagePullSecrets:
{{- range .Values.global.imagePullSecrets }}
  - name: {{ . }}
{{- end }}
{{- end }}
{{- end }}
