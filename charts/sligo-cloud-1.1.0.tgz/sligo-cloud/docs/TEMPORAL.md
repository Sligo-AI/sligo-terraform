# Temporal self-hosted (Enterprise)

Sligo can run a production Temporal cluster alongside the app stack using the official [`temporalio/temporal`](https://github.com/temporalio/helm-charts) Helm subchart (chart `1.2.0`, server `1.31.0`).

## Enablement

Set in your environment values (or via Terraform `helm_release` values):

```yaml
temporal:
  enabled: true
  selfHosted: true
  namespace: sligo-prod          # Temporal namespace (not K8s)
  taskQueue: sligo-workflows
  persistence:
    host: <postgres-host>        # managed Postgres private IP / RDS endpoint
    port: 5432
    user: <postgres-user>

temporalWorker:
  enabled: true

temporal-server:
  server:
    config:
      persistence:
        numHistoryShards: 512
        datastores:
          default:
            sql:
              host: <postgres-host>
              user: <postgres-user>
          visibility:
            sql:
              host: <postgres-host>
              user: <postgres-user>
    namespaces:
      namespace:
        - name: sligo-prod
          retention: 720h
  web:
    enabled: true                # ClusterIP only; Super Admin proxy in sligo-app
```

For local dev only, use `temporal.enabled: true`, `temporal.selfHosted: false`, `temporal.type: internal` (in-memory `start-dev` — not for production).

## Kubernetes secrets (created by Terraform)

| Secret | Keys | Consumer |
|--------|------|----------|
| `temporal-db-credentials` | `host`, `port`, `database`, `username`, `password` | Temporal default store |
| `temporal-visibility-db-credentials` | same | Temporal visibility store |
| `backend-secrets` | `TEMPORAL_ADDRESS`, `TEMPORAL_NAMESPACE`, `TEMPORAL_TASK_QUEUE`, `TEMPORAL_TLS` | backend, temporal-worker |
| `mcp-gateway-secrets` | `TEMPORAL_*` | MCP gateway (Temporal MCP server) |

Postgres databases `temporal` and `temporal_visibility` are created by Terraform on the customer's managed Postgres instance. Schema setup runs via the subchart's Helm schema hook (`temporal-sql-tool setup-schema`).

## Sizing (defaults)

| Component | CPU request | Memory request |
|-----------|-------------|----------------|
| frontend | 100m | 256Mi |
| matching | 100m | 256Mi |
| internal-worker | 100m | 256Mi |
| history | 500m | 1Gi |

## Web UI (Super Admin only)

The Temporal Web UI is deployed as `temporal-web:8080` (ClusterIP). It is **not** exposed on a public ingress.

Super Admins open **`/super-admin/temporal`** in sligo-app. The app proxies to `TEMPORAL_UI_URL` (default `http://temporal-web:8080`) after `requireSuperAdmin()` validates the session.

## Upgrades

When upgrading the Temporal server image or chart:

1. Pin chart and server image together in `Chart.yaml` / `temporal-server.server.image.tag`.
2. Run schema migration (`temporal-sql-tool update-schema`) via the subchart schema hook before or as part of the Helm upgrade.
3. Never run newer server binaries against an older schema.

See [Temporal server upgrades](https://docs.temporal.io/self-hosted-guide/upgrade-server).

## gRPC address

Sligo clients use `temporal-frontend:7233` inside the cluster (`temporal.frontendAddress`).
